/*
    ShineFonts Bridge.jsx
    Background After Effects startup bridge for ShineFonts -> After Effects font sends.

    Install to:
    /Applications/Adobe After Effects 2026/Scripts/Startup/ShineFonts Bridge.jsx

    No panel is required. Once After Effects launches, this script watches:
    ~/Library/Application Support/Shine Font Manager/AfterEffectsCommands

    When ShineFonts sends an applyFont command:
    - selected text layer(s): apply the requested font
    - no selected text layer: create "ShineFonts", center its anchor to the text,
      and center the layer in the active comp
*/

(function shineFontsBridgeStartup() {
    var USER_HOME_PATH = trim($.getenv("HOME"));
    var AE_BRIDGE_ROOT_PATH = USER_HOME_PATH
        ? USER_HOME_PATH + "/Library/Application Support/Shine Font Manager"
        : Folder.userData.fsName + "/Shine Font Manager";
    var AE_COMMANDS_PATH = AE_BRIDGE_ROOT_PATH + "/AfterEffectsCommands";
    var AE_RESPONSES_PATH = AE_BRIDGE_ROOT_PATH + "/AfterEffectsResponses";
    var AE_FALLBACK_COMMANDS_PATH = Folder.userData.fsName + "/Shine Font Manager/AfterEffectsCommands";
    var APPLY_COMMAND_TIMEOUT_MS = 20000;
    var POLL_INTERVAL_MS = 500;

    function trim(s) {
        return String(s || "").replace(/^\s+|\s+$/g, "");
    }

    function safeFilePart(s) {
        var cleaned = trim(s).replace(/[^A-Za-z0-9._-]+/g, "_");
        return cleaned.length ? cleaned : "ShineFonts";
    }

    function jsonEscape(s) {
        s = String(s || "");
        return s
            .replace(/\\/g, "\\\\")
            .replace(/\"/g, "\\\"")
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n")
            .replace(/\t/g, "\\t");
    }

    function jsonString(s) {
        if (s === null || s === undefined) return "null";
        return "\"" + jsonEscape(s) + "\"";
    }

    function uuid() {
        var d = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
        }).toUpperCase();
    }

    function pad(n) { return (n < 10 ? "0" : "") + n; }

    function isoDate(d) {
        return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()) +
            "T" + pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + ":" + pad(d.getUTCSeconds()) + "Z";
    }

    function ensureFolder(folder) {
        if (!folder.exists && !folder.create()) {
            throw new Error("Could not create folder:\n" + folder.fsName);
        }
        return folder;
    }

    function parseApplyFontCommandText(text) {
        if (!text || !text.length) return null;
        try {
            if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(text);
        } catch (eJSON) {}

        function stringValue(key) {
            var marker = "\"" + key + "\"";
            var keyPos = text.indexOf(marker);
            if (keyPos < 0) return "";
            var colonPos = text.indexOf(":", keyPos + marker.length);
            if (colonPos < 0) return "";
            var quotePos = text.indexOf("\"", colonPos + 1);
            if (quotePos < 0) return "";
            var out = "";
            var escaped = false;
            for (var i = quotePos + 1; i < text.length; i++) {
                var ch = text.charAt(i);
                if (escaped) {
                    if (ch === "n") out += "\n";
                    else if (ch === "r") out += "\r";
                    else if (ch === "t") out += "\t";
                    else out += ch;
                    escaped = false;
                } else if (ch === "\\") {
                    escaped = true;
                } else if (ch === "\"") {
                    return out;
                } else {
                    out += ch;
                }
            }
            return out;
        }

        function numberValue(key) {
            var marker = "\"" + key + "\"";
            var keyPos = text.indexOf(marker);
            if (keyPos < 0) return 0;
            var colonPos = text.indexOf(":", keyPos + marker.length);
            if (colonPos < 0) return 0;
            var tail = text.substring(colonPos + 1);
            var m = /-?[0-9]+/.exec(tail);
            return m ? Number(m[0]) : 0;
        }

        var command = {
            id: stringValue("id"),
            action: stringValue("action"),
            postScriptName: stringValue("postScriptName"),
            displayName: stringValue("displayName"),
            source: stringValue("source"),
            createdAtMilliseconds: numberValue("createdAtMilliseconds")
        };
        return command.action ? command : null;
    }

    function readJSONFile(file) {
        try {
            if (!file || !file.exists) return null;
            file.encoding = "UTF-8";
            if (!file.open("r")) return null;
            var text = file.read();
            file.close();
            return parseApplyFontCommandText(text);
        } catch (e) {
            try { if (file && file.opened) file.close(); } catch (eClose) {}
            return null;
        }
    }

    function writeApplyFontResponse(command, status, message, appliedCount) {
        try {
            var folder = ensureFolder(new Folder(AE_RESPONSES_PATH));
            var id = trim(command && command.id ? command.id : uuid());
            var file = new File(folder.fsName + "/ApplyFontResponse_" + safeFilePart(id) + ".json");
            var body = "{\n" +
                "  \"id\" : " + jsonString(id) + ",\n" +
                "  \"action\" : \"applyFontResponse\",\n" +
                "  \"status\" : " + jsonString(status) + ",\n" +
                "  \"message\" : " + jsonString(message) + ",\n" +
                "  \"appliedCount\" : " + String(appliedCount || 0) + ",\n" +
                "  \"completedDate\" : " + jsonString(isoDate(new Date())) + "\n" +
                "}\n";
            file.encoding = "UTF-8";
            if (file.open("w")) {
                file.write(body);
                file.close();
            }
        } catch (e) {}
    }

    function commandAgeMilliseconds(command) {
        try {
            var created = Number(command.createdAtMilliseconds || 0);
            if (!created || isNaN(created)) return 0;
            return Math.max(0, new Date().getTime() - created);
        } catch (e) {
            return 0;
        }
    }

    function fontIsAvailableInAE(postScriptName) {
        try {
            if (app.fonts && app.fonts.getFontsByPostScriptName) {
                var matches = app.fonts.getFontsByPostScriptName(postScriptName);
                return matches && matches.length > 0;
            }
        } catch (e) {}
        return true;
    }

    function selectedTextLayerSourceProperties() {
        var result = [];
        try {
            if (!app.project) return result;
            var comp = app.project.activeItem;
            if (!(comp instanceof CompItem)) return result;

            var layers = comp.selectedLayers || [];
            for (var i = 0; i < layers.length; i++) {
                try {
                    var textProps = layers[i].property("ADBE Text Properties");
                    if (!textProps) continue;
                    var sourceText = textProps.property("ADBE Text Document");
                    if (!sourceText) continue;
                    result.push(sourceText);
                } catch (eLayer) {}
            }
        } catch (e) {}
        return result;
    }

    function centerAnchorPointToTextBounds(layer, compTime) {
        try {
            if (!layer || !layer.sourceRectAtTime) return;
            var rect = layer.sourceRectAtTime(compTime, false);
            if (!rect) return;

            var transform = layer.property("ADBE Transform Group");
            if (!transform) return;

            var anchorProp = transform.property("ADBE Anchor Point");
            if (anchorProp) {
                anchorProp.setValue([
                    rect.left + (rect.width / 2),
                    rect.top + (rect.height / 2)
                ]);
            }
        } catch (eCenterAnchor) {}
    }

    function centerLayerInComp(layer, comp) {
        try {
            if (!layer || !comp) return;
            var transform = layer.property("ADBE Transform Group");
            if (!transform) return;

            var positionProp = transform.property("ADBE Position");
            if (positionProp) {
                positionProp.setValue([comp.width / 2, comp.height / 2]);
            }
        } catch (eCenterLayer) {}
    }

    function createCenteredPlaceholderTextLayer(postScriptName) {
        try {
            if (!app.project) {
                return { status: "waitingSelection", appliedCount: 0, error: "" };
            }

            var comp = app.project.activeItem;
            if (!(comp instanceof CompItem)) {
                return { status: "waitingSelection", appliedCount: 0, error: "" };
            }

            var layer = comp.layers.addText("ShineFonts");
            if (!layer) {
                return { status: "error", appliedCount: 0, error: "After Effects could not create a text layer." };
            }

            try { layer.name = "ShineFonts Text"; } catch (eName) {}

            var textProps = layer.property("ADBE Text Properties");
            var sourceText = textProps ? textProps.property("ADBE Text Document") : null;
            if (!sourceText) {
                return { status: "error", appliedCount: 0, error: "After Effects could not access the new text layer." };
            }

            var td = sourceText.value;
            td.text = "ShineFonts";
            td.font = postScriptName;
            sourceText.setValue(td);

            centerAnchorPointToTextBounds(layer, comp.time);
            centerLayerInComp(layer, comp);

            try {
                for (var i = 1; i <= comp.numLayers; i++) {
                    comp.layer(i).selected = false;
                }
                layer.selected = true;
            } catch (eSelect) {}

            return { status: "applied", appliedCount: 1, error: "" };
        } catch (eCreate) {
            return { status: "error", appliedCount: 0, error: eCreate.toString() };
        }
    }

    function applyFontToSelectedTextLayers(postScriptName) {
        var props = selectedTextLayerSourceProperties();

        if (!fontIsAvailableInAE(postScriptName)) {
            return { status: "waitingFont", appliedCount: 0, error: "" };
        }

        var applied = 0;
        var errors = [];

        app.beginUndoGroup("ShineFonts - Apply Font");
        try {
            if (!props.length) {
                return createCenteredPlaceholderTextLayer(postScriptName);
            }

            for (var i = 0; i < props.length; i++) {
                try {
                    var td = props[i].value;
                    td.font = postScriptName;
                    props[i].setValue(td);
                    applied++;
                } catch (eApply) {
                    errors.push(eApply.toString());
                }
            }
        } finally {
            try { app.endUndoGroup(); } catch (eUndo) {}
        }

        if (applied > 0) {
            return { status: "applied", appliedCount: applied, error: errors.join("\n") };
        }

        return {
            status: "error",
            appliedCount: 0,
            error: errors.join("\n") || "After Effects could not apply the font."
        };
    }

    function pendingApplyCommandFiles() {
        var paths = [AE_COMMANDS_PATH];
        if (AE_FALLBACK_COMMANDS_PATH !== AE_COMMANDS_PATH) paths.push(AE_FALLBACK_COMMANDS_PATH);

        var files = [];
        var seen = {};
        for (var p = 0; p < paths.length; p++) {
            try {
                var folder = new Folder(paths[p]);
                if (!folder.exists) continue;
                var found = folder.getFiles("ApplyFont_*.json");
                for (var i = 0; found && i < found.length; i++) {
                    var key = found[i].fsName;
                    if (!seen[key]) {
                        seen[key] = true;
                        files.push(found[i]);
                    }
                }
            } catch (eFolder) {}
        }
        return files;
    }

    function processApplyFontCommands() {
        try {
            var files = pendingApplyCommandFiles();
            if (!files || !files.length) return;

            files.sort(function(a, b) {
                try { return a.modified.getTime() - b.modified.getTime(); } catch (e) { return 0; }
            });

            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var command = readJSONFile(file);

                if (!command || trim(command.action) !== "applyFont") {
                    continue;
                }

                var postScriptName = trim(command.postScriptName);
                var displayName = trim(command.displayName) || postScriptName || "Font";

                if (!postScriptName) {
                    writeApplyFontResponse(
                        command,
                        "error",
                        "The ShineFonts command did not include a PostScript font name.",
                        0
                    );
                    try { file.remove(); } catch (eNoPSRemove) {}
                    continue;
                }

                if (commandAgeMilliseconds(command) > APPLY_COMMAND_TIMEOUT_MS) {
                    var timeoutMessage = "Timed out waiting to apply " + displayName + ".";
                    writeApplyFontResponse(command, "timeout", timeoutMessage, 0);
                    try { file.remove(); } catch (eTimeoutRemove) {}
                    continue;
                }

                var result = applyFontToSelectedTextLayers(postScriptName);

                if (result.status === "waitingSelection" || result.status === "waitingFont") {
                    return;
                }

                if (result.status === "applied") {
                    var appliedMessage = "Applied " + displayName + " to " +
                        result.appliedCount + " text layer" +
                        (result.appliedCount === 1 ? "." : "s.");
                    writeApplyFontResponse(command, "applied", appliedMessage, result.appliedCount);
                    try { file.remove(); } catch (eAppliedRemove) {}
                    continue;
                }

                var errorMessage = "Could not apply " + displayName + ". " + (result.error || "");
                writeApplyFontResponse(command, "error", errorMessage, 0);
                try { file.remove(); } catch (eErrorRemove) {}
            }
        } catch (eProcess) {}
    }

    function installBackgroundWatcher() {
        // Replace any previous watcher installed during this AE session.
        try {
            if ($.global.shineFontsBridgeTaskID) {
                app.cancelTask($.global.shineFontsBridgeTaskID);
            }
        } catch (eCancelOld) {}

        $.global.shineFontsBridgePoll = function() {
            try { processApplyFontCommands(); } catch (ePoll) {}
        };

        try {
            ensureFolder(new Folder(AE_COMMANDS_PATH));
        } catch (eFolder) {}

        try {
            processApplyFontCommands();
        } catch (eInitial) {}

        try {
            $.global.shineFontsBridgeTaskID = app.scheduleTask(
                "try { if ($.global.shineFontsBridgePoll) $.global.shineFontsBridgePoll(); } catch (e) {}",
                POLL_INTERVAL_MS,
                true
            );
        } catch (eSchedule) {
            $.global.shineFontsBridgeTaskID = 0;
        }
    }

    installBackgroundWatcher();
})();
