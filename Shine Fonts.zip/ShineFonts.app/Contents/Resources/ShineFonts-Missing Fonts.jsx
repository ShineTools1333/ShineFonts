/*
    PRODUCTION BUILD: uses /Volumes/ShineFonts only.\n    Shine Fonts Auto Missing Fonts.jsx

    Background/startup helper for Adobe After Effects.

    INSTALL TO:
    /Applications/Adobe After Effects 2026/Scripts/Startup/Shine Fonts Auto Missing Fonts.jsx

    WHAT IT DOES:
    - Runs silently in the background while After Effects is open.
    - Watches app.fonts.missingOrSubstitutedFonts.
    - Automatically writes the SAME request JSON files used by the existing
      Shine Fonts Missing Fonts panel:
          /Volumes/ShineFonts/Requests
    - Reads:
          /Volumes/ShineFonts/AdobeFontReferences.json
      so the temporary popup can identify missing Adobe Fonts.
    - Shows a small non-modal status palette only while a project has missing fonts.
    - Automatically closes the palette shortly after After Effects reports that
      all fonts are available again.

    The existing "Shine Fonts Missing Fonts.jsx" ScriptUI panel can remain installed
    as a manual/troubleshooting tool. This startup helper does not require that panel
    to be open.
*/

(function shineFontsAutoMissingFonts() {
    var APP_NAME = "Shine Fonts";
    var USER_HOME_PATH = trim($.getenv("HOME"));

    // Production shared root only. The old ~/Desktop/ShineFontsTest fallback is gone.
    var ROOT_PATH = "/Volumes/ShineFonts";
    var REQUESTS_PATH = ROOT_PATH + "/Requests";
    var ADOBE_REFERENCES_PATH = ROOT_PATH + "/AdobeFontReferences.json";

    // Canonical local IPC bridge shared with ShineFonts v163+.
    var AE_COMMANDS_PATH = USER_HOME_PATH +
        "/Library/Application Support/ShineFonts/ShineFonts Manager/AfterEffectsCommands";

    function refreshShineFontsPaths() {
        // Kept as a no-op so the rest of the proven request code remains untouched.
        ROOT_PATH = "/Volumes/ShineFonts";
        REQUESTS_PATH = ROOT_PATH + "/Requests";
        ADOBE_REFERENCES_PATH = ROOT_PATH + "/AdobeFontReferences.json";
    }

    // Adaptive watcher timing: stay quiet when AE has no missing fonts so the
    // startup helper spends far less time entering AE's main scripting/UI thread.
    // As soon as a missing font is observed, temporarily switch back to a fast cadence.
    var IDLE_SCAN_INTERVAL_MS = 3000;
    var ACTIVE_SCAN_INTERVAL_MS = 750;
    var REQUEST_RETRY_MS = 30000;
    var SUCCESS_CLOSE_DELAY_MS = 2800;
    var FIND_TIMEOUT_MS = 45000;

    var state = {
        popup: null,
        accentBand: null,
        eyebrow: null,
        statusIcon: null,
        title: null,
        names: null,
        namesPanel: null,
        footerRow: null,
        okButton: null,
        okButtonWrap: null,
        cancelButtonWrap: null,
        cancelButton: null,
        lastMissingKey: "",
        lastMissingFonts: [],
        lastAdobeMatches: [],
        lastRequestedAtByKey: {},
        lastProjectKey: "",
        allResolvedAt: 0,
        scanTaskID: 0,
        spinnerTaskID: 0,
        spinnerRunning: false,
        spinnerFrame: 0,
        lastObservedMissingCount: 0,
        searchKey: "",
        searchStartedAt: 0,
        warningDismissedKey: "",
        cancelledKey: "",
        cancelledProjectKey: "",
        displaySessionFonts: [],
        displaySessionProjectKey: ""
    };

    function trim(s) {
        return String(s || "").replace(/^\s+|\s+$/g, "");
    }

    function normalizeName(s) {
        return trim(s)
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "");
    }


    function inferFamilyAndStyleFromPostScript(postScriptName, familyName, styleName) {
        var ps = trim(postScriptName);
        var family = trim(familyName);
        var style = trim(styleName);

        // AE's missing-font API sometimes gives only a PostScript name, e.g.
        // "RobocodeRegular", even though the shared file/registry may be named
        // "Robocode-Regular". Derive conservative family/style hints for the request.
        if ((!family || !style) && ps) {
            var knownStyles = [
                "ExtraBlack", "UltraBlack", "ExtraBold", "UltraBold",
                "SemiBold", "DemiBold", "ExtraLight", "UltraLight",
                "CondensedBold", "CondensedLight", "Condensed",
                "BlackItalic", "BoldItalic", "SemiBoldItalic", "DemiBoldItalic",
                "LightItalic", "MediumItalic", "RegularItalic",
                "Black", "Heavy", "Bold", "SemiBold", "DemiBold",
                "Medium", "Book", "Regular", "Roman",
                "Light", "Thin", "Italic", "Oblique"
            ];

            var normalizedPS = ps.replace(/[-_\s]+/g, "");

            for (var i = 0; i < knownStyles.length; i++) {
                var candidateStyle = knownStyles[i];
                var normalizedStyle = candidateStyle.replace(/[-_\s]+/g, "");
                if (normalizedPS.length > normalizedStyle.length &&
                    normalizedPS.substr(normalizedPS.length - normalizedStyle.length).toLowerCase() === normalizedStyle.toLowerCase()) {

                    if (!style) style = candidateStyle;

                    if (!family) {
                        var familyLength = normalizedPS.length - normalizedStyle.length;
                        family = normalizedPS.substr(0, familyLength);
                    }
                    break;
                }
            }

            // Hyphenated PostScript names often expose family-style directly.
            if ((!family || !style) && ps.indexOf("-") >= 0) {
                var parts = ps.split("-");
                if (!family && parts.length > 1) family = trim(parts[0]);
                if (!style && parts.length > 1) style = trim(parts.slice(1).join(" "));
            }
        }

        return {
            familyName: family,
            styleName: style
        };
    }

    function safeFilePart(s) {
        var cleaned = trim(s).replace(/[^A-Za-z0-9._-]+/g, "_");
        return cleaned.length ? cleaned : "Font_Request";
    }

    function safeGet(obj, prop) {
        try {
            if (obj && obj[prop] !== undefined && obj[prop] !== null) {
                return String(obj[prop]);
            }
        } catch (e) {}
        return "";
    }

    function jsonEscape(s) {
        s = String(s || "");
        return s
            .replace(/\\/g, "\\\\")
            .replace(/\"/g, "\\\"")
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n")
            .replace(/\t/g, "\\t");
    }

    function jsonString(s) {
        if (s === null || s === undefined) return "null";
        return "\"" + jsonEscape(s) + "\"";
    }

    function uuid() {
        var d = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
        }).toUpperCase();
    }

    function pad(n) {
        return (n < 10 ? "0" : "") + n;
    }

    function isoDate(d) {
        return d.getUTCFullYear() + "-" +
            pad(d.getUTCMonth() + 1) + "-" +
            pad(d.getUTCDate()) + "T" +
            pad(d.getUTCHours()) + ":" +
            pad(d.getUTCMinutes()) + ":" +
            pad(d.getUTCSeconds()) + "Z";
    }

    function machineUserName() {
        try {
            var u = trim($.getenv("USER"));
            if (u) return u;
        } catch (e1) {}
        try {
            var u2 = trim($.getenv("USERNAME"));
            if (u2) return u2;
        } catch (e2) {}
        return "Unknown";
    }

    function currentProjectName() {
        try {
            if (app.project && app.project.file) {
                return app.project.file.name;
            }
        } catch (e) {}
        return "Untitled AE Project";
    }

    function currentProjectKey() {
        var name = currentProjectName();
        var path = "";
        try {
            if (app.project && app.project.file) {
                path = app.project.file.fsName || "";
            }
        } catch (e) {}
        return normalizeName(path || name);
    }

    function getMissingFonts() {
        var results = [];
        var seen = {};

        if (!app.fonts ||
            app.fonts.missingOrSubstitutedFonts === undefined) {
            return results;
        }

        var missing = app.fonts.missingOrSubstitutedFonts;
        if (!missing || missing.length === 0) return results;

        for (var i = 0; i < missing.length; i++) {
            var f = missing[i];

            var postScriptName = trim(safeGet(f, "postScriptName"));
            var familyName = trim(safeGet(f, "familyName"));
            var styleName = trim(safeGet(f, "styleName"));
            var fullName = trim(safeGet(f, "fullName"));
            var name = trim(safeGet(f, "name"));
            var fontName = trim(safeGet(f, "fontName"));

            var inferred = inferFamilyAndStyleFromPostScript(
                postScriptName,
                familyName,
                styleName
            );
            familyName = inferred.familyName;
            styleName = inferred.styleName;

            var displayName =
                postScriptName ||
                fullName ||
                fontName ||
                name ||
                trim(familyName + " " + styleName) ||
                String(f);

            displayName = trim(displayName);
            if (!displayName || displayName === "[object Object]") {
                displayName = "Unknown Font";
            }

            var key = normalizeName(
                postScriptName ||
                fullName ||
                displayName
            );

            if (!key || seen[key]) continue;
            seen[key] = true;

            results.push({
                key: key,
                displayName: displayName,
                postScriptName: postScriptName,
                familyName: familyName,
                styleName: styleName,
                fullName: fullName
            });
        }

        return results;
    }

    function missingListKey(fonts) {
        var parts = [];
        for (var i = 0; i < fonts.length; i++) {
            parts.push(fonts[i].key);
        }
        parts.sort();
        return parts.join("|");
    }

    function ensureRequestsFolder() {
        var folder = new Folder(REQUESTS_PATH);
        if (!folder.exists && !folder.create()) {
            throw new Error(
                "Could not create Requests folder:\n" +
                REQUESTS_PATH
            );
        }
        return folder;
    }

    function readJSONFile(file) {
        try {
            if (!file || !file.exists) return null;
            file.encoding = "UTF-8";
            if (!file.open("r")) return null;
            var txt = file.read();
            file.close();
            if (!txt) return null;
            return JSON.parse(txt);
        } catch (e) {
            try { if (file && file.opened) file.close(); } catch (e2) {}
            return null;
        }
    }

    function requestMatchesFont(request, font) {
        if (!request || !font) return false;

        var names = [
            request.requestedFontName,
            request.requestedPostScriptName,
            request.requestedFamilyName,
            request.requestedStyleName
        ];

        var fontNames = [
            font.postScriptName,
            font.fullName,
            font.displayName,
            font.familyName,
            trim(font.familyName + " " + font.styleName)
        ];

        for (var i = 0; i < names.length; i++) {
            var a = normalizeName(names[i]);
            if (!a) continue;

            for (var j = 0; j < fontNames.length; j++) {
                var b = normalizeName(fontNames[j]);
                if (b && a === b) return true;
            }
        }

        return false;
    }

    function existingRequestForFont(font) {
        var folder = new Folder(REQUESTS_PATH);
        if (!folder.exists) return null;

        var files;
        try {
            files = folder.getFiles("*.json");
        } catch (e) {
            return null;
        }

        var user = machineUserName();
        var project = currentProjectName();

        for (var i = 0; i < files.length; i++) {
            var obj = readJSONFile(files[i]);
            if (!obj) continue;

            if (trim(obj.requestedByMachine) !== user) continue;

            // Prefer a project-specific duplicate match, but tolerate older requests
            // that predate the requestedProjectName field.
            var reqProject = trim(obj.requestedProjectName);
            if (reqProject && reqProject !== project) continue;

            var status = trim(obj.status).toLowerCase();
            if (status !== "open" &&
                status !== "assigned" &&
                status !== "fulfilled") {
                continue;
            }

            if (requestMatchesFont(obj, font)) {
                return obj;
            }
        }

        return null;
    }

    function requestJSON(fontInfo) {
        var id = uuid();
        var user = machineUserName();
        var displayName =
            fontInfo.postScriptName ||
            fontInfo.displayName ||
            fontInfo.fullName ||
            trim(fontInfo.familyName + " " + fontInfo.styleName) ||
            "Unknown Font";

        var now = isoDate(new Date());
        var project = currentProjectName();

        return {
            id: id,
            safeName: safeFilePart(displayName),
            text:
                "{\n" +
                "  \"id\" : " + jsonString(id) + ",\n" +
                "  \"requestedFontName\" : " + jsonString(displayName) + ",\n" +
                "  \"requestedPostScriptName\" : " + jsonString(fontInfo.postScriptName) + ",\n" +
                "  \"requestedFamilyName\" : " + jsonString(fontInfo.familyName) + ",\n" +
                "  \"requestedStyleName\" : " + jsonString(fontInfo.styleName) + ",\n" +
                "  \"requestedFamilyStyleName\" : " + jsonString(trim(fontInfo.familyName + " " + fontInfo.styleName)) + ",\n" +
                "  \"requestedFamilyStylePostScriptLike\" : " + jsonString(trim(fontInfo.familyName + "-" + fontInfo.styleName)) + ",\n" +
                "  \"requestedProjectName\" : " + jsonString(project) + ",\n" +
                "  \"requestedAdobeReferenceID\" : " + jsonString(fontInfo.adobeReferenceID || "") + ",\n" +
                "  \"requestedAdobeDetailURL\" : " + jsonString(fontInfo.adobeDetailURL || "") + ",\n" +
                "  \"requestSource\" : \"After Effects Auto\",\n" +
                "  \"requestedByMachine\" : " + jsonString(user) + ",\n" +
                "  \"requestedByUser\" : " + jsonString(user) + ",\n" +
                "  \"requestedDate\" : " + jsonString(now) + ",\n" +
                "  \"status\" : \"Open\",\n" +
                "  \"fulfilledByMachine\" : null,\n" +
                "  \"fulfilledByUser\" : null,\n" +
                "  \"fulfilledDate\" : null,\n" +
                "  \"fulfilledFileName\" : null,\n" +
                "  \"assignedToMachine\" : null,\n" +
                "  \"assignedToUser\" : null,\n" +
                "  \"assignedDate\" : null,\n" +
                "  \"declinedByMachines\" : []\n" +
                "}\n"
        };
    }

    function createRequest(font) {
        var folder = ensureRequestsFolder();
        var req = requestJSON(font);
        var file = new File(
            folder.fsName + "/" +
            req.safeName + "_" +
            req.id + ".json"
        );

        file.encoding = "UTF-8";
        if (!file.open("w")) {
            throw new Error(
                "Could not open request file for writing."
            );
        }

        file.write(req.text);
        file.close();
        return file.fsName;
    }

    function removeResolvedOwnRequests(currentFonts) {
        var folder = new Folder(REQUESTS_PATH);
        if (!folder.exists) return;

        var files;
        try {
            files = folder.getFiles("*.json");
        } catch (e) {
            return;
        }

        var user = machineUserName();
        var project = currentProjectName();

        for (var i = 0; i < files.length; i++) {
            var obj = readJSONFile(files[i]);
            if (!obj) continue;
            if (trim(obj.requestedByMachine) !== user) continue;

            var reqProject = trim(obj.requestedProjectName);
            if (reqProject && reqProject !== project) continue;

            var stillMissing = false;
            for (var j = 0; j < currentFonts.length; j++) {
                if (requestMatchesFont(obj, currentFonts[j])) {
                    stillMissing = true;
                    break;
                }
            }

            // Once AE itself says the font is no longer missing, this request is done.
            // Normal ShineFonts fulfillment may already have deleted the JSON; Adobe
            // activation requests otherwise need this cleanup because no font binary is
            // copied through the request system.
            if (!stillMissing) {
                try { files[i].remove(); } catch (eRemove) {}
            }
        }
    }

    function requestMissingFontsAutomatically(fonts) {
        var now = new Date().getTime();
        var projectKey = currentProjectKey();
        var created = 0;

        if (state.lastProjectKey !== projectKey) {
            state.lastProjectKey = projectKey;
            state.lastRequestedAtByKey = {};
        }

        for (var i = 0; i < fonts.length; i++) {
            var font = fonts[i];
            var throttleKey = projectKey + "|" + font.key;

            if (existingRequestForFont(font)) {
                state.lastRequestedAtByKey[throttleKey] = now;
                continue;
            }

            var lastAt = state.lastRequestedAtByKey[throttleKey] || 0;
            if (lastAt && (now - lastAt) < REQUEST_RETRY_MS) {
                continue;
            }

            try {
                createRequest(font);
                state.lastRequestedAtByKey[throttleKey] = now;
                created++;
            } catch (eRequest) {
                // Keep the helper non-blocking. The popup will report that the
                // ShineFonts volume/request path is unavailable.
            }
        }

        return created;
    }

    function readAdobeReferences() {
        var file = new File(ADOBE_REFERENCES_PATH);
        var refs = readJSONFile(file);
        if (!refs || !(refs instanceof Array)) return [];
        return refs;
    }

    function referenceMatchesFont(ref, font) {
        if (!ref || !font) return false;

        var family = normalizeName(ref.familyName);
        var id = normalizeName(ref.id);

        var names = [
            normalizeName(font.familyName),
            normalizeName(font.displayName),
            normalizeName(font.fullName),
            normalizeName(font.postScriptName)
        ];

        for (var i = 0; i < names.length; i++) {
            var candidate = names[i];
            if (!candidate) continue;

            if (family &&
                (candidate === family ||
                 candidate.indexOf(family) === 0 ||
                 family.indexOf(candidate) === 0)) {
                return true;
            }

            if (id && candidate === id) return true;
        }

        return false;
    }

    function adobeMatchesForFonts(fonts) {
        var refs = readAdobeReferences();
        var matches = [];

        for (var i = 0; i < fonts.length; i++) {
            var matched = null;

            for (var j = 0; j < refs.length; j++) {
                if (referenceMatchesFont(refs[j], fonts[i])) {
                    matched = refs[j];
                    break;
                }
            }

            if (matched) {
                matches.push({
                    font: fonts[i],
                    reference: matched
                });
            }
        }

        return matches;
    }

    function isAdobeFont(font, adobeMatches) {
        for (var i = 0; i < adobeMatches.length; i++) {
            if (adobeMatches[i].font.key === font.key) return true;
        }
        return false;
    }

    function openURL(urlString) {
        var url = trim(urlString);
        if (!url) return;

        try {
            if ($.os.toLowerCase().indexOf("mac") >= 0) {
                system.callSystem(
                    'open "' +
                    url.replace(/"/g, '\\"') +
                    '"'
                );
            }
        } catch (e) {}
    }

    function openShineFonts() {
        try {
            if ($.os.toLowerCase().indexOf("mac") >= 0) {
                system.callSystem('open -a "ShineFonts"');
            }
        } catch (e1) {
            try {
                system.callSystem('open -a "Shine Fonts"');
            } catch (e2) {}
        }
    }

    function setIconColor(rgba) {
        try {
            if (!state.statusIcon) return;
            state.statusIcon.graphics.foregroundColor =
                state.statusIcon.graphics.newBrush(
                    state.statusIcon.graphics.BrushType.SOLID_COLOR,
                    rgba
                );
        } catch (eColor) {}
    }

    function stopTextSpinner(showSuccess) {
        state.spinnerRunning = false;

        try {
            if (state.spinnerTaskID) {
                app.cancelTask(state.spinnerTaskID);
                state.spinnerTaskID = 0;
            }
        } catch (eCancel) {}

        if (!state.statusIcon) return;

        try {
            if (showSuccess) {
                state.statusIcon.text = "✓";
                applySuccessTheme();
            } else {
                state.statusIcon.text = "◐";
                applyWorkingTheme();
            }

            if (state.popup && state.popup.visible) {
                state.popup.update();
            }
        } catch (eIcon) {}
    }

    function startTextSpinner() {
        if (state.spinnerRunning) return;
        if (!state.statusIcon) return;

        state.spinnerRunning = true;
        var frames = ["◐", "◓", "◑", "◒"];

        $.global.shineFontsAutoMissingFontsCompactSpinner = function() {
            try {
                if (!state.spinnerRunning || !state.statusIcon) return;

                state.spinnerFrame =
                    (state.spinnerFrame + 1) % frames.length;

                state.statusIcon.text =
                    frames[state.spinnerFrame];

                applyWorkingTheme();

                if (state.popup && state.popup.visible) {
                    state.popup.update();
                }
            } catch (eSpin) {}
        };

        try {
            state.spinnerTaskID = app.scheduleTask(
                "try { if ($.global.shineFontsAutoMissingFontsCompactSpinner) $.global.shineFontsAutoMissingFontsCompactSpinner(); } catch (e) {}",
                180,
                true
            );
        } catch (eSchedule) {
            state.spinnerRunning = false;
        }
    }

    function setBrush(control, propertyName, rgba) {
        try {
            if (!control || !control.graphics) return;
            control.graphics[propertyName] =
                control.graphics.newBrush(
                    control.graphics.BrushType.SOLID_COLOR,
                    rgba
                );
        } catch (eBrush) {}
    }

    function setPen(control, propertyName, rgba, width) {
        try {
            if (!control || !control.graphics) return;
            control.graphics[propertyName] =
                control.graphics.newPen(
                    control.graphics.PenType.SOLID_COLOR,
                    rgba,
                    width || 1
                );
        } catch (ePen) {}
    }

    function applyWorkingTheme() {
        try {
            setBrush(state.accentBand, "backgroundColor", [1.00, 0.76, 0.00, 1]);
            setIconColor([1.00, 0.78, 0.00, 1]);
            if (state.eyebrow) {
                state.eyebrow.graphics.foregroundColor =
                    state.eyebrow.graphics.newPen(
                        state.eyebrow.graphics.PenType.SOLID_COLOR,
                        [1.00, 0.78, 0.00, 1],
                        1
                    );
            }
        } catch (eTheme) {}
    }

    function applySuccessTheme() {
        try {
            setBrush(state.accentBand, "backgroundColor", [0.18, 0.86, 0.34, 1]);
            setIconColor([0.18, 0.86, 0.34, 1]);
            if (state.eyebrow) {
                state.eyebrow.graphics.foregroundColor =
                    state.eyebrow.graphics.newPen(
                        state.eyebrow.graphics.PenType.SOLID_COLOR,
                        [0.18, 0.86, 0.34, 1],
                        1
                    );
            }
        } catch (eTheme) {}
    }

    function applyWarningTheme() {
        try {
            setBrush(state.accentBand, "backgroundColor", [0.92, 0.34, 0.16, 1]);
            setIconColor([0.92, 0.34, 0.16, 1]);
            if (state.eyebrow) {
                state.eyebrow.graphics.foregroundColor =
                    state.eyebrow.graphics.newPen(
                        state.eyebrow.graphics.PenType.SOLID_COLOR,
                        [0.92, 0.34, 0.16, 1],
                        1
                    );
            }
        } catch (eTheme) {}
    }

    function removeOwnOpenRequestsForFonts(fonts) {
        var folder = new Folder(REQUESTS_PATH);
        if (!folder.exists) return;

        var files;
        try {
            files = folder.getFiles("*.json");
        } catch (e) {
            return;
        }

        var user = machineUserName();
        var project = currentProjectName();

        for (var i = 0; i < files.length; i++) {
            var obj = readJSONFile(files[i]);
            if (!obj) continue;
            if (trim(obj.requestedByMachine) !== user) continue;

            var reqProject = trim(obj.requestedProjectName);
            if (reqProject && reqProject !== project) continue;

            var status = trim(obj.status).toLowerCase();
            if (status !== "open" && status !== "assigned") continue;

            for (var j = 0; j < fonts.length; j++) {
                if (requestMatchesFont(obj, fonts[j])) {
                    try { files[i].remove(); } catch (eRemove) {}
                    break;
                }
            }
        }
    }

    function clearButtonFocusRing() {
        try {
            if (state.popup) {
                state.popup.defaultElement = null;
                state.popup.cancelElement = null;
            }
        } catch (eDefaultButton) {}

        try { if (state.cancelButton) state.cancelButton.active = false; } catch (eCancelFocus) {}
        try { if (state.okButton) state.okButton.active = false; } catch (eOKFocus) {}
    }

    function ensurePopup() {
        if (state.popup) return state.popup;

        var win = new Window(
            "palette",
            "Shine Fonts",
            undefined,
            { closeButton: false }
        );

        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 0;
        win.margins = 0;

        // Strong visual accent without turning the entire palette bright yellow.
        var accentBand = win.add("panel");
        accentBand.alignment = ["fill", "top"];
        accentBand.margins = 0;
        try {
            accentBand.preferredSize = [10, 9];
            accentBand.minimumSize = [10, 9];
            accentBand.maximumSize = [10000, 9];
        } catch (eAccentSize) {}
        setBrush(accentBand, "backgroundColor", [1.00, 0.76, 0.00, 1]);

        var card = win.add("group");
        card.orientation = "column";
        card.alignChildren = ["fill", "top"];
        card.alignment = ["fill", "top"];
        card.spacing = 0;
        card.margins = [16, 12, 16, 14];

        // Slightly deeper neutral surface if ScriptUI honors group background brushes.
        setBrush(card, "backgroundColor", [0.12, 0.12, 0.12, 1]);

        var contentRow = card.add("group");
        contentRow.orientation = "row";
        contentRow.alignChildren = ["left", "top"];
        contentRow.alignment = ["fill", "top"];
        contentRow.spacing = 4;
        contentRow.margins = 0;

        var iconCol = contentRow.add("group");
        iconCol.orientation = "column";
        iconCol.alignChildren = ["center", "top"];
        iconCol.alignment = ["left", "top"];
        iconCol.spacing = 0;
        iconCol.margins = [0, 12, 0, 0];

        try {
            iconCol.preferredSize = [26, 48];
            iconCol.minimumSize = [26, 48];
            iconCol.maximumSize = [26, 48];
        } catch (eIconColSize) {}

        var statusIcon = iconCol.add(
            "statictext",
            undefined,
            "◐"
        );
        statusIcon.alignment = ["center", "top"];
        statusIcon.justify = "center";

        try {
            statusIcon.preferredSize = [26, 34];
            statusIcon.minimumSize = [26, 34];
            statusIcon.maximumSize = [26, 34];
            statusIcon.graphics.font = ScriptUI.newFont(
                statusIcon.graphics.font.name,
                "BOLD",
                31
            );
        } catch (eIconFont) {}

        var textCol = contentRow.add("group");
        textCol.orientation = "column";
        textCol.alignChildren = ["fill", "top"];
        textCol.alignment = ["fill", "top"];
        textCol.spacing = 0;
        textCol.margins = 0;

        try {
            textCol.preferredSize = [350, -1];
            textCol.minimumSize = [350, -1];
        } catch (eTextColSize) {}

        var eyebrow = textCol.add(
            "statictext",
            undefined,
            "SHINE FONTS"
        );
        eyebrow.alignment = ["fill", "top"];
        eyebrow.justify = "left";

        try {
            eyebrow.preferredSize = [350, 16];
            eyebrow.graphics.font = ScriptUI.newFont(
                eyebrow.graphics.font.name,
                "BOLD",
                10
            );
            eyebrow.graphics.foregroundColor =
                eyebrow.graphics.newPen(
                    eyebrow.graphics.PenType.SOLID_COLOR,
                    [1.00, 0.78, 0.00, 1],
                    1
                );
        } catch (eEyebrow) {}

        var title = textCol.add(
            "statictext",
            undefined,
            "Finding Missing Fonts…"
        );
        title.alignment = ["fill", "top"];
        title.justify = "left";

        try {
            title.preferredSize = [350, 26];
            title.graphics.font = ScriptUI.newFont(
                title.graphics.font.name,
                "BOLD",
                17
            );
        } catch (eTitle) {}

        // Put the font list on the card itself rather than inside the text column.
        // This gives the list equal left/right inset from the dialog edges even though
        // the status icon occupies space only in the header row.
        var namesGroup = card.add("group");
        namesGroup.orientation = "column";
        namesGroup.alignChildren = ["fill", "top"];
        namesGroup.alignment = ["fill", "top"];
        namesGroup.spacing = 0;
        namesGroup.margins = [0, 8, 0, 0];

        var namesPanel = namesGroup.add("panel");
        namesPanel.alignment = ["fill", "top"];
        namesPanel.margins = [10, 8, 10, 8];

        // Darker inset list area so the installed/missing font names read as a
        // distinct status section within the main card.
        setBrush(namesPanel, "backgroundColor", [0.075, 0.075, 0.075, 1]);

        try {
            // Fixed height for approximately 6 font rows.
            namesPanel.preferredSize = [380, 138];
            namesPanel.minimumSize = [380, 138];
        } catch (eNamesPanel) {}

        var names = namesPanel.add(
            "statictext",
            undefined,
            "",
            { multiline: true }
        );
        names.alignment = ["fill", "top"];
        names.justify = "left";

        try {
            names.preferredSize = [328, 118];
            names.minimumSize = [328, 118];
            names.graphics.font = ScriptUI.newFont(
                names.graphics.font.name,
                "REGULAR",
                13
            );
        } catch (eNames) {}

        var footerRow = card.add("group");
        footerRow.orientation = "row";
        footerRow.alignChildren = ["center", "center"];
        footerRow.alignment = ["fill", "top"];
        footerRow.spacing = 0;
        footerRow.margins = [0, 8, 0, 0];
        footerRow.visible = false;

        // One fixed centered action slot. Cancel and OK occupy the exact same physical
        // rectangle and we only toggle which wrapper is visible, so the button can never
        // jump horizontally between working/success/warning states.
        var actionSlot = footerRow.add("group");
        actionSlot.orientation = "stack";
        actionSlot.alignChildren = ["center", "center"];
        actionSlot.alignment = ["center", "center"];
        actionSlot.margins = 0;
        actionSlot.spacing = 0;
        actionSlot.preferredSize = [88, 24];
        actionSlot.minimumSize = [88, 24];
        actionSlot.maximumSize = [88, 24];

        // Proven ShineTools native-button stack-cell architecture: wrapper and button
        // are both 24 px high, avoiding both the blue focus halo and edge clipping.
        var cancelWrap = actionSlot.add("group");
        cancelWrap.orientation = "stack";
        cancelWrap.alignChildren = ["fill", "fill"];
        cancelWrap.alignment = ["center", "center"];
        cancelWrap.margins = 0;
        cancelWrap.spacing = 0;
        cancelWrap.preferredSize = [88, 24];
        cancelWrap.minimumSize = [88, 24];
        cancelWrap.maximumSize = [88, 24];

        var cancelButton = cancelWrap.add("button", undefined, "Cancel");
        cancelButton.alignment = ["fill", "fill"];
        cancelButton.preferredSize = [88, 24];
        cancelButton.minimumSize = [88, 24];
        cancelButton.maximumSize = [88, 24];
        try { cancelButton.justify = "center"; } catch (eCancelJustify) {}

        cancelButton.onClick = function() {
            try {
                cancelButton.active = false;
                state.cancelledKey = state.lastMissingKey;
                state.cancelledProjectKey = currentProjectKey();
                removeOwnOpenRequestsForFonts(state.lastMissingFonts || []);
                hidePopup();
                cancelButton.active = false;
            } catch (eCancelSearch) {}
        };

        var okWrap = actionSlot.add("group");
        okWrap.orientation = "stack";
        okWrap.alignChildren = ["fill", "fill"];
        okWrap.alignment = ["center", "center"];
        okWrap.margins = 0;
        okWrap.spacing = 0;
        okWrap.preferredSize = [88, 24];
        okWrap.minimumSize = [88, 24];
        okWrap.maximumSize = [88, 24];

        var okButton = okWrap.add("button", undefined, "OK");
        okButton.alignment = ["fill", "fill"];
        okButton.preferredSize = [88, 24];
        okButton.minimumSize = [88, 24];
        okButton.maximumSize = [88, 24];
        try { okButton.justify = "center"; } catch (eOKJustify) {}
        okWrap.visible = false;

        okButton.onClick = function() {
            try {
                okButton.active = false;
                if (state.searchKey) {
                    state.warningDismissedKey = state.searchKey;
                }
                hidePopup();
                okButton.active = false;
            } catch (eOK) {}
        };

        state.popup = win;
        state.accentBand = accentBand;
        state.eyebrow = eyebrow;
        state.statusIcon = statusIcon;
        state.title = title;
        state.names = names;
        state.namesPanel = namesPanel;
        state.footerRow = footerRow;
        state.okButton = okButton;
        state.cancelButton = cancelButton;
        state.okButtonWrap = okWrap;
        state.cancelButtonWrap = cancelWrap;

        try { win.defaultElement = null; } catch (eDefaultElement) {}
        try { win.cancelElement = null; } catch (eCancelElement) {}
        clearButtonFocusRing();

        applyWorkingTheme();

        return win;
    }

    function showPopupIfNeeded() {
        var win = ensurePopup();

        try {
            if (!win.visible) {
                win.center();
                win.show();
                clearButtonFocusRing();
            }
        } catch (e) {}
    }

    function hidePopup() {
        stopTextSpinner(false);

        try {
            if (state.popup && state.popup.visible) {
                state.popup.hide();
            }
        } catch (e) {}
    }

    function compactFontNames(fonts, successMode) {
        var lines = [];
        var maxRows = Math.min(fonts.length, 6);

        for (var i = 0; i < maxRows; i++) {
            lines.push(
                (successMode ? "✓  " : "") +
                fonts[i].displayName
            );
        }

        if (fonts.length > maxRows) {
            lines.push(
                "+" +
                (fonts.length - maxRows) +
                " more"
            );
        }

        return lines.join("\n");
    }


    // DISPLAY-ONLY tracking for a multi-font search.
    // The request creation/matching logic does not use this state.
    function updateDisplaySession(fonts, projectKey) {
        fonts = fonts || [];

        var shouldStartNewSession =
            state.displaySessionProjectKey !== projectKey ||
            !state.displaySessionFonts ||
            state.displaySessionFonts.length === 0 ||
            (state.allResolvedAt && fonts.length > 0);

        if (shouldStartNewSession) {
            state.displaySessionProjectKey = projectKey;
            state.displaySessionFonts = fonts.slice(0);
            return;
        }

        // Preserve fonts that AE has already resolved, and append only genuinely new
        // missing fonts that appear during the same project/search session.
        var seen = {};
        var i;
        for (i = 0; i < state.displaySessionFonts.length; i++) {
            seen[state.displaySessionFonts[i].key] = true;
        }

        for (i = 0; i < fonts.length; i++) {
            if (!seen[fonts[i].key]) {
                state.displaySessionFonts.push(fonts[i]);
                seen[fonts[i].key] = true;
            }
        }
    }

    function displayFontNames(currentMissingFonts, mode) {
        var sessionFonts =
            (state.displaySessionFonts && state.displaySessionFonts.length)
                ? state.displaySessionFonts
                : (currentMissingFonts || []);

        var missing = {};
        var i;
        for (i = 0; i < (currentMissingFonts || []).length; i++) {
            missing[currentMissingFonts[i].key] = true;
        }

        var lines = [];
        var maxRows = Math.min(sessionFonts.length, 6);

        for (i = 0; i < maxRows; i++) {
            var font = sessionFonts[i];
            var prefix = "";

            if (mode === "success") {
                prefix = "✓  ";
            } else if (mode === "warning") {
                prefix = missing[font.key] ? "!  " : "✓  ";
            } else {
                prefix = missing[font.key] ? "" : "✓  ";
            }

            lines.push(prefix + font.displayName);
        }

        if (sessionFonts.length > maxRows) {
            lines.push("+" + (sessionFonts.length - maxRows) + " more");
        }

        return lines.join("\n");
    }

    function updatePopup(fonts, adobeMatches) {
        // Keep the original completion condition that already proved reliable.
        if (!fonts || fonts.length === 0) {
            if (!state.allResolvedAt) {
                state.allResolvedAt = new Date().getTime();
            }

            if (state.popup) {
                try {
                    stopTextSpinner(true);

                    var completedFonts =
                        (state.displaySessionFonts && state.displaySessionFonts.length)
                            ? state.displaySessionFonts
                            : state.lastMissingFonts;

                    state.title.text =
                        completedFonts.length === 1
                            ? "Font Ready"
                            : "Fonts Ready";

                    state.names.text =
                        displayFontNames([], "success");

                    try {
                        // Keep the same dark font-name box on success; only add a checkmark
                        // in front of each installed font name.
                        var successRows = Math.max(
                            1,
                            Math.min(completedFonts.length, 6)
                        );
                        // Keep the same six-row list area in the success state.
                        state.names.preferredSize = [328, 118];
                        if (state.namesPanel) {
                            state.namesPanel.preferredSize = [380, 138];
                        }
                    } catch (eSuccessNamesSize) {}

                    if (state.footerRow) state.footerRow.visible = true;
                    if (state.cancelButtonWrap) state.cancelButtonWrap.visible = false;
                    if (state.okButtonWrap) state.okButtonWrap.visible = true;

                    state.popup.layout.layout(true);
                    state.popup.layout.resize();
                    state.popup.update();
                    clearButtonFocusRing();
                } catch (eResolved) {}
            }
            return;
        }

        state.allResolvedAt = 0;
        state.lastMissingFonts = fonts.slice(0);
        state.lastAdobeMatches = adobeMatches || [];

        showPopupIfNeeded();

        try {
            applyWorkingTheme();
            if (state.footerRow) state.footerRow.visible = true;
            if (state.cancelButtonWrap) state.cancelButtonWrap.visible = true;
            if (state.okButtonWrap) state.okButtonWrap.visible = false;

            if (adobeMatches && adobeMatches.length > 0) {
                state.title.text =
                    adobeMatches.length === 1
                        ? "Adobe Font Needs Activation"
                        : "Adobe Fonts Need Activation";
            } else {
                state.title.text =
                    fonts.length === 1
                        ? "Finding Missing Font…"
                        : "Finding Missing Fonts…";
            }

            state.names.text =
                displayFontNames(fonts, "working");

            try {
                var workingRows = Math.max(
                    1,
                    Math.min(fonts.length, 4)
                );
                // Keep a consistent six-row list area while working.
                state.names.preferredSize = [328, 118];
                if (state.namesPanel) {
                    state.namesPanel.preferredSize = [380, 138];
                }
            } catch (eWorkingNamesSize) {}

            state.popup.layout.layout(true);
            state.popup.layout.resize();
            clearButtonFocusRing();
            startTextSpinner();
        } catch (eUI) {}
    }


    function showNotFoundWarning(fonts) {
        state.lastMissingFonts = fonts.slice(0);
        showPopupIfNeeded();

        try {
            stopTextSpinner(false);
            applyWarningTheme();
            if (state.statusIcon) state.statusIcon.text = "!";
            state.title.text =
                fonts.length === 1
                    ? "Font Could Not Be Found"
                    : "Fonts Could Not Be Found";
            state.names.text = displayFontNames(fonts, "warning");

            if (state.footerRow) state.footerRow.visible = true;
            if (state.cancelButtonWrap) state.cancelButtonWrap.visible = false;
            if (state.okButtonWrap) state.okButtonWrap.visible = true;

            state.popup.layout.layout(true);
            state.popup.layout.resize();
            state.popup.update();
        } catch (eWarningUI) {}
    }


    function processShineFontsApplyFontCommands() {
        var folder = new Folder(AE_COMMANDS_PATH);
        if (!folder.exists) return;

        var files;
        try {
            files = folder.getFiles("ApplyFont_*.json");
        } catch (eListCommands) {
            return;
        }

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var command = readJSONFile(file);
            if (!command || trim(command.action) !== "applyFont") {
                try { file.remove(); } catch (eBadCommandRemove) {}
                continue;
            }

            var postScriptName = trim(command.postScriptName);
            if (!postScriptName) {
                try { file.remove(); } catch (eNoFontRemove) {}
                continue;
            }

            var applied = false;
            try {
                var comp = app.project ? app.project.activeItem : null;
                if (comp && comp.selectedLayers && comp.selectedLayers.length > 0) {
                    for (var j = 0; j < comp.selectedLayers.length; j++) {
                        var layer = comp.selectedLayers[j];
                        var sourceText = null;
                        try { sourceText = layer.property("Source Text"); } catch (eSourceText) {}
                        if (!sourceText) continue;

                        var textDocument = sourceText.value;
                        textDocument.font = postScriptName;
                        sourceText.setValue(textDocument);
                        applied = true;
                    }
                }
            } catch (eApplyFontCommand) {
                applied = false;
            }

            // Commands are one-shot. Remove after a successful application. If there is
            // no selected text layer yet, leave the command in place for the next 1s tick.
            if (applied) {
                try { file.remove(); } catch (eAppliedRemove) {}
            }
        }
    }

    function hasPendingShineFontsApplyFontCommands() {
        try {
            var folder = new Folder(AE_COMMANDS_PATH);
            if (!folder.exists) return false;
            var files = folder.getFiles("ApplyFont_*.json");
            return files && files.length > 0;
        } catch (ePendingCommands) {
            return false;
        }
    }

    function idleMissingFontsProbe() {
        // This is intentionally the only continuous idle work. Do not refresh ShineFonts
        // paths, read Adobe reference JSON, inspect request files, or rebuild project keys
        // while AE has no missing fonts.
        var previousMissingCount = state.lastObservedMissingCount || 0;
        var fonts = getMissingFonts();
        state.lastObservedMissingCount = fonts.length;

        if (fonts.length > 0) {
            // Missing fonts appeared: enter the existing full resolver immediately.
            scanAndResolve();
            return;
        }

        // If we just transitioned from missing -> resolved, run one final full pass so
        // request cleanup and the success popup remain exactly as before. Steady-state
        // zero-missing ticks never do this work.
        if (previousMissingCount > 0) {
            scanAndResolve();
            return;
        }

        // Preserve ShineFonts "Send/Apply Font to AE" commands without running the rest
        // of the missing-font machinery. The folder is checked cheaply; command parsing
        // happens only when an actual command exists.
        if (hasPendingShineFontsApplyFontCommands()) {
            processShineFontsApplyFontCommands();
        }
    }

    function scanAndResolve() {
        try {
            processShineFontsApplyFontCommands();
            refreshShineFontsPaths();

            var fonts = getMissingFonts();
            state.lastObservedMissingCount = fonts.length;
            var key = missingListKey(fonts);
            var projectKey = currentProjectKey();
            var combinedSearchKey = projectKey + "|" + key;
            var now = new Date().getTime();

            // Keep the popup's original font group independently from AE's shrinking
            // missing-font list. This does not participate in request creation or matching.
            updateDisplaySession(fonts, projectKey);

            // A user-cancelled search stays cancelled only for this exact project/missing-font set.
            // A project change or a different missing-font set automatically allows searching again.
            if (state.cancelledKey &&
                (state.cancelledKey !== key || state.cancelledProjectKey !== projectKey)) {
                state.cancelledKey = "";
                state.cancelledProjectKey = "";
            }

            if (fonts.length > 0 &&
                state.cancelledKey === key &&
                state.cancelledProjectKey === projectKey) {
                state.lastMissingKey = key;
                state.lastMissingFonts = fonts.slice(0);
                return;
            }

            if (fonts.length > 0 && state.searchKey !== combinedSearchKey) {
                state.searchKey = combinedSearchKey;
                state.searchStartedAt = now;
                state.warningDismissedKey = "";
            }

            var adobeMatches = adobeMatchesForFonts(fonts);

            // Mark known Adobe references directly on the AE request payload. ShineFonts
            // then knows this is an activation request, not a request to copy a font binary
            // from another workstation.
            for (var am = 0; am < adobeMatches.length; am++) {
                adobeMatches[am].font.adobeReferenceID =
                    trim(adobeMatches[am].reference.id);
                adobeMatches[am].font.adobeDetailURL =
                    trim(adobeMatches[am].reference.detailURL);
            }

            // Always keep completion state fresh, but only rewrite request files when
            // the actual missing set/project changes or a retry interval has elapsed.
            if (fonts.length > 0) {
                requestMissingFontsAutomatically(fonts);
            }

            removeResolvedOwnRequests(fonts);

            // There is no explicit "not found" reply in the request protocol. Treat a
            // non-Adobe font that remains missing for 45 seconds as a warning condition.
            // The background request remains alive, so a late match can still resolve it.
            if (fonts.length > 0 && state.searchStartedAt &&
                (now - state.searchStartedAt) >= FIND_TIMEOUT_MS) {
                var unresolvedNonAdobe = [];
                for (var nf = 0; nf < fonts.length; nf++) {
                    if (!isAdobeFont(fonts[nf], adobeMatches)) {
                        unresolvedNonAdobe.push(fonts[nf]);
                    }
                }

                if (unresolvedNonAdobe.length > 0) {
                    state.lastMissingKey = key;
                    if (state.warningDismissedKey !== state.searchKey) {
                        showNotFoundWarning(unresolvedNonAdobe);
                    }
                    return;
                }
            }

            if (key !== state.lastMissingKey ||
                fonts.length === 0 ||
                adobeMatches.length !== state.lastAdobeMatches.length) {
                state.lastMissingKey = key;

                // IMPORTANT: do not overwrite the saved non-empty font list when AE
                // reaches zero missing fonts. updatePopup() uses lastMissingFonts to
                // render the success rows as "✓ Font Name".
                if (fonts.length > 0) {
                    state.lastMissingFonts = fonts.slice(0);
                }

                updatePopup(fonts, adobeMatches);
            } else if (fonts.length > 0) {
                // Keep the popup's visibility/state healthy even if the set did not change.
                updatePopup(fonts, adobeMatches);
            }
        } catch (eScan) {
            // Background helper must never block AE with repeated alerts.
        }
    }

    $.global.shineFontsAutoMissingFontsScheduleNext = function(delayMS) {
        try {
            var nextDelay = Number(delayMS);
            if (!nextDelay || nextDelay < 250) {
                nextDelay = IDLE_SCAN_INTERVAL_MS;
            }

            state.scanTaskID = app.scheduleTask(
                "try { if ($.global.shineFontsAutoMissingFontsTick) $.global.shineFontsAutoMissingFontsTick(); } catch (e) {}",
                nextDelay,
                false
            );

            if (state.scanTaskID !== undefined &&
                state.scanTaskID !== null &&
                Number(state.scanTaskID) > 0) {
                $.global.shineFontsAutoMissingFontsStarted = true;
                $.global.shineFontsAutoMissingFontsScanTaskID = state.scanTaskID;
                return true;
            }
        } catch (eScheduleNext) {}

        try {
            $.global.shineFontsAutoMissingFontsStarted = false;
        } catch (eResetStarted) {}
        return false;
    };

    $.global.shineFontsAutoMissingFontsTick = function() {
        var nextDelay = IDLE_SCAN_INTERVAL_MS;

        try {
            idleMissingFontsProbe();
            $.global.shineFontsAutoMissingFontsLastTick = new Date().getTime();

            // Missing fonts are the only time we need the fast loop. Once AE reaches
            // zero missing fonts, immediately fall back to the quieter 3-second cadence.
            nextDelay =
                state.lastObservedMissingCount > 0
                    ? ACTIVE_SCAN_INTERVAL_MS
                    : IDLE_SCAN_INTERVAL_MS;
        } catch (e) {
            // If a scan ever throws, remain conservative and quiet, but always keep
            // the watcher alive by scheduling the next one-shot task below.
            nextDelay = IDLE_SCAN_INTERVAL_MS;
        }

        $.global.shineFontsAutoMissingFontsScheduleNext(nextDelay);
    };

    // Avoid duplicate watchers if startup evaluates twice in one AE session.
    try {
        if ($.global.shineFontsAutoMissingFontsStarted) {
            // A manual rerun still gets an immediate health scan. The active scheduler
            // continues to own the next background tick.
            try {
                scanAndResolve();
                $.global.shineFontsAutoMissingFontsLastTick = new Date().getTime();
            } catch (eHealthScan) {}
            return;
        }
    } catch (eStartedCheck) {}

    // Immediate startup scan, then schedule one adaptive one-shot task. Unlike the old
    // fragile self-rescheduling version, the scheduling call is outside scanAndResolve()
    // and is attempted even when the scan throws or AE delays execution around a modal.
    try {
        scanAndResolve();
        $.global.shineFontsAutoMissingFontsLastTick = new Date().getTime();
    } catch (eInitialScan) {}

    var firstDelay =
        state.lastObservedMissingCount > 0
            ? ACTIVE_SCAN_INTERVAL_MS
            : IDLE_SCAN_INTERVAL_MS;

    $.global.shineFontsAutoMissingFontsScheduleNext(firstDelay);

})();
